package com.example.game_suit_chp4

import android.widget.ImageView

class validasiJawaban {

    fun valid(){

    }
}