package com.example.game_suit_chp4

fun main(args: Array<String>) {
//    val maen = GameSuit()
//
//    while (maen.ck==0) {
//        maen.answer.comChoice = maen.answer.dataJawaban.random()
//        maen.play()
//        maen.lanjut()
//    }
}

