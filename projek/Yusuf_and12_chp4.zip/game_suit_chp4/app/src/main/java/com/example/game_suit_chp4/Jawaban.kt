package com.example.game_suit_chp4

import androidx.core.view.isVisible
import com.example.game_suit_chp4.databinding.ActivityMainBinding

class Jawaban {
    lateinit var binding: ActivityMainBinding
    val dataJawaban = mutableListOf("batu","gunting","kertas")
    var comChoice: String = ""

    var batuP1 = binding.batuP1
    var guntingP1 = binding.guntingP1
    var kertasP1 = binding.kertasP1

    var batuCom = binding.batuCom
    var guntingCom = binding.guntingCom
    var kertasCom = binding.kertasCom

    var gameStatus = binding.gameStatus

    fun pilihBatu(){
      binding.aktiveBatuP1.isVisible
        when(comChoice){
            "batu"-> {
                binding.aktiveBatuCom.isVisible
                binding.gameStatus.setText("@strings.draw")
            }
            "gunting"-> {
                binding.aktiveBatuP1.isVisible
                binding.gameStatus.setText("@strings.pemain1_menang")
            }
            "kertas"-> {
                binding.aktiveBatuP1.isVisible
                binding.gameStatus.setText("@strings.com_menang")
            }
        }
    }
    fun pilihGunting(){
        binding.activeGuntingP1.isVisible
        when(comChoice){
            "batu"-> {
                binding.gameStatus.setText("@strings.com_menang")
                binding.batuCom.isVisible
            }
            "gunting"-> {
                binding.gameStatus.setText("@strings.draw")
                binding.activeGuntingCom.isVisible
            }
            "kertas"-> {
                binding.gameStatus.setText("@strings.pemain1_menang")
                binding.kertasCom.isVisible
            }
        }
    }
    fun pilihKertas(){
        binding.activeKertasP1.isVisible
        when(comChoice){
            "batu"-> {
                binding.gameStatus.setText("@strings.pemain1_menang")
                binding.aktiveBatuCom.isVisible
            }
            "gunting"-> {
                binding.gameStatus.setText("@strings.computer_menang")
                binding.activeGuntingCom.isVisible
            }
            "kertas"-> {
                binding.gameStatus.setText("@string.draw")
                binding.activeKertasCom.isVisible
            }
        }
    }
}