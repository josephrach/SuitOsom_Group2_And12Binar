package com.example.game_suit_chp4

abstract class Game() {
    abstract fun play()

}